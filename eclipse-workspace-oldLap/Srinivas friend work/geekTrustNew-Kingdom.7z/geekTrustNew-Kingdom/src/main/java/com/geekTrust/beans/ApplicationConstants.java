package com.geekTrust.beans;

public class ApplicationConstants {

	public static final String UNIVERSE_PROPERTY_FILE_NAME = "universe.properties";
	public static final String SOUTHEROS = "Southeras";
	public static final String SPACE = "space";

}
