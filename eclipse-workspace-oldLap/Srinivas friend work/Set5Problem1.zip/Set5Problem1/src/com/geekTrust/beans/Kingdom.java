package com.geekTrust.beans;

import java.util.List;

public class Kingdom implements IMessageSender {

	private String king;
	private String emblem;
	private String message;
	private String animal;
	private boolean isKing;
	private List<Kingdom> allies;
	private List<Kingdom> allKingdomsMessageSend;

	public String getKing() {
		return king;
	}

	public void setKing(String king) {
		this.king = king;
	}

	public String getEmblem() {
		return emblem;
	}

	public void setEmblem(String emblem) {
		this.emblem = emblem;
	}

	public boolean isKing() {
		return isKing;
	}

	public void setKing(boolean isKing) {
		this.isKing = isKing;
	}

	public List<Kingdom> getAllies() {
		return allies;
	}

	public void setAllies(List<Kingdom> allies) {
		this.allies = allies;
	}

	public List<Kingdom> getAllKingdomsMessageSend() {
		return allKingdomsMessageSend;
	}

	public void setAllKingdomsMessageSend(List<Kingdom> allKingdomsMessageSend) {
		this.allKingdomsMessageSend = allKingdomsMessageSend;
	}

	@Override
	public void sendMesage(String message) {
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}

	
	public String getAnimal() {
		return animal;
	}

	public void setAnimal(String animal) {
		this.animal = animal;
	}
	
	@Override
	public String toString() {
		
		return emblem;
	}
}
