package com.geekTrust.beans;

public interface IMessageSender {

	void sendMesage(String message);

	String getMessage();
}
