package com.geekTrust.beans;

import java.util.Map;

public interface IKingdomProvider {

	Map<String , Map<String, Kingdom>> getKingdoms();

}
