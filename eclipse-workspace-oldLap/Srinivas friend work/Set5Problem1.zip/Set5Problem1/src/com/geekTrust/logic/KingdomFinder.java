package com.geekTrust.logic;

import java.util.ArrayList;
import java.util.List;

import com.geekTrust.beans.Kingdom;

public class KingdomFinder {
	private final static int rulerVictoryCount = 3;

	public Kingdom findRulerAndAllies(Kingdom senderKingdom) {

		List<Kingdom> allKingdomsMessageSent = senderKingdom.getAllKingdomsMessageSend();
		List<Kingdom> allies = new ArrayList<>();
		int expectedVictoryCounter = 0;

		for (Kingdom kingdom : allKingdomsMessageSent) {
			String messageRecieved = kingdom.getMessage();
			String sortedMessage = KingdomUtil.sort(messageRecieved);
			String animal = kingdom.getAnimal();
			String sortedAnimal = KingdomUtil.sort(animal);
			boolean isMesageValid = KingdomUtil.compareData(sortedAnimal, sortedMessage);
			if (isMesageValid) {
				expectedVictoryCounter++;
				allies.add(kingdom);
			}

		}

		if (expectedVictoryCounter >= rulerVictoryCount) {
			senderKingdom.setKing(senderKingdom.getKing());
			senderKingdom.setKing(true);
		}

		else {
			senderKingdom.setKing("None");
			allies = null;
		}

		senderKingdom.setAllies(allies);

		return senderKingdom;

	}
}
