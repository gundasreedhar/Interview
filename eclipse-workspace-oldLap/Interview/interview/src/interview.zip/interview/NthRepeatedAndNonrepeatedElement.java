package interview;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class NthRepeatedAndNonrepeatedElement {
	public static void nthRepeatedAndNonrepeatedElement(int[] arr, int n)
	{
		List<Integer> nonReapeatedList = new ArrayList<Integer>();
		List<Integer> repeatedList = new ArrayList<Integer>();
		for(int a : arr )
		{
			if(repeatedList.contains(a))
				continue;
			
			if(nonReapeatedList.contains(a)){
				nonReapeatedList.remove((Object)a);
				repeatedList.add(a);
			}
			else 
				nonReapeatedList.add(a);
		}
		
		System.out.println("Repeated elements : " + repeatedList);
		System.out.println( "Non-repeated elements : " + nonReapeatedList);
		System.out.println("---------------------------");
		System.out.println(n + " Repeated element: " + repeatedList.get(n-1));
		System.out.println(n + " Non-repeated element : " + nonReapeatedList.get(n-1));
	}
	public static void main(String[] args) {
		int[] arr = {12,3,4,6,6,4,3,2};
		nthRepeatedAndNonrepeatedElement(arr,2);
	}

}
