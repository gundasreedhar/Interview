package interview;

// for this problem we should not solve by sorting the given array 
// coz {1,2,3,3} for this sorted array the second highest is 2 but gives 3.
public class FindSecondHeigestNumber {
	static int SecondHeigestNumber(int[] array) {
		int f = array[0], s = 0;
		boolean flag = false;
		try {
				
				// code for initializing the first and second variable
				// coz for fatal input arrays
				// {-1,-2,-3,-4} here u cant assign zero to first and second variable coz it gives Zero as O/P
				// {3,3,3,3,3} array with all same elements
				for (int a : array) {
					if (a != f) // assign second element which is not same as first
					{
						s = a;
						flag = true;
						break;
					}
				}
				if (flag == false) // if array have all same elements then second will be same as first
					s = f;
				//till here
				
				
				for (int a : array) {
					if (a > f) {
						s = f;
						f = a;
					} else if (a > s && a != f) // a!=f coz there is chance that repeated second highest
						// element might be there
					{
						s = a;
					}
				}
		}
		catch(ArrayIndexOutOfBoundsException ex)
		{
			ex.printStackTrace();
		}
		return s;

	}

	public static void main(String... args) {
		int[] array1 = { 2, 5, 25, 28, 1, 8, 26, 27, 28 };
		int[] array2 = { -1, -2, -3 };// {2,5,25,28,1,8,26,27,28};
		int[] array3 = { 3, 3, 3, 3 };
		int[] array4 = { -1, -2, 1 };

		System.out.println("second heigest number : " + SecondHeigestNumber(array4));

	}
}
