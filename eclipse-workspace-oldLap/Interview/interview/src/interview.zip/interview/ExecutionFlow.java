package interview;

class Launch
{
	public static void main(String[] args )
	{
		Parent p = new Childd();
		
	}
}

class Childd extends Parent
{
	static 
	{
		System.out.println("static block of child");
	}
	
	{
		System.out.println("non static block of child");
	}
	
	Childd(){
		
		System.out.println("Child's constructor");
	}
}

class Parent
{
	static {
		System.out.println("static block of parent");
	}
	
	{
		System.out.println("non static block of parent");
	}
	
	Parent()
	{
		System.out.println("parents constructor");
	}
}


