package interview;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class Checkk {
	
	public static int factorial(int num)
	{
		if(num == 0)
			return 1;
		
		return num * factorial(num-1);
	}
	
	static public void factors(int num)
	{ // factors
		List<Integer> factors = new ArrayList<>();
		factors.add(1);
		
		for(int i = 2 ;i<=num/2;i++)
		{
			if(num%i == 0)
				factors.add(i);
		}
		System.out.println(factors);
		
	}
	
	static public void fibnocci(int num)
	{
		try {
			int [] arr = new int[num];
			arr[0] = 0; arr[1] = 1;
			
			for(int i = 2 ; i< num ;i ++) {
				arr[i] = arr[i-1] + arr[i-2];
			}
			
			System.out.println(Arrays.toString(arr));
		}
		catch(NullPointerException | ArrayIndexOutOfBoundsException ex)
		{
			ex.printStackTrace();
		}
		
		
		
	}
	
	public static void main(String... args)
	{
//		Set<Integer> set = new HashSet<>();
//		set.add(1);set.add(2);set.add(3);
//		System.out.println(set);
//		System.out.println(set.add(1));
//		
//		Map<Integer,Integer> map =
//				new HashMap<>();
//		map.put(1,2);
//		System.out.println(map);
//		System.out.println(map.put(1,3));
//		System.out.println(map);
//		String[] str = {"sdjb","asdh"};
//		int [] arrint = {1,2,3,4};
//		List<String> al = Arrays.asList(str);
//		
//		List<Integer> list = Arrays.stream(arrint).boxed().collect(Collectors.toList());
//		Integer[] arrrr = list.stream().toArray(Integer::new).;
//		Integer[] arrr= (Integer[]) list.toArray();
//		
//		List<Integer> all = new ArrayList<>(arrint);
//		System.out.println(al.getClass());
//		System.out.println(all.getClass());
		
//		Studentt stu1 = new Studentt(1,"shreedhar");
//		Studentt stu2 = null;
//		System.out.println(String.valueOf(stu1).getClass());
//		System.out.println(String.valueOf(stu2));
//		System.out.println(stu2.toString());
		
		
		
		//fibnocci(5);
		
		
		Studentt nn = new Studentt(1,"sdf")
		{
			public int usn = 0;
			public void go() {}
			 int getUSn() {return usn;}
			
		};
		
		System.out.println(nn.getUSn());
		
		
		Dog pintu = new Dog()
		{
			int a = 1;
		};
		
		pintu.a;
	}
	
}
class Studentt
{
	int roll;
	String name;
	Studentt(int roll,String name)
	{
		this.roll = roll;
		this.name = name;
	}
	
	 int getUSn() {
		// TODO Auto-generated method stub
		return 1;
	} 

	@Override
	public String toString() {
		return "Studentt [roll=" + roll + ", name=" + name + "]";
	}
	
	
}

interface Dog{

	}