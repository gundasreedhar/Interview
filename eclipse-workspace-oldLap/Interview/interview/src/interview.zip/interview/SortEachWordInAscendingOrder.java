package interview;
 
public class SortEachWordInAscendingOrder {
	public static void main(String [] args)
	{
		
	}
}

