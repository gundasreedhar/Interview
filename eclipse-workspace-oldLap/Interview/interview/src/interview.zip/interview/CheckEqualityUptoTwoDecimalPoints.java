package interview;

public class CheckEqualityUptoTwoDecimalPoints {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float a = 123.2523f;
		float b = 123.2566f;
		
		System.out.println((int)a*100==(int)b*100);
	}

}
