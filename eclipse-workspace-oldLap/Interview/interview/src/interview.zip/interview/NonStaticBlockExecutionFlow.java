package interview;

//
class Parent {
	Parent() {
		System.out.println("parent class constructor");
	}

	void disp() {
		System.out.println("parent class mrthod");
	}
}

class Child extends Parent {
	void disp() {
		super.disp();
		System.out.println("child class method");
	}

	Child() {
		// super.disp(); // possible
		super();
		System.out.println("Object's class constructor");
	}

	{
		System.out.println("non static block");
	}
}

public class NonStaticBlockExecutionFlow {
	public static void main(String... args) {
		Parent c = new Child();
		c.disp();
	}
}
