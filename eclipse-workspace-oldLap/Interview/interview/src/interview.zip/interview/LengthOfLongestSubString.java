package interview;

public class LengthOfLongestSubString {
	
	public static int lengthOfLongestSubString(String str)
	{
		String [] strArr = str.split("_");
		int length = strArr[0].length();
		
		for(int i = 1 ; i<strArr.length ; i++)
		{
			if(length < strArr[i].length())
				length = strArr[i].length();
		}
		
		return length;
	}

	public static void main(String[] args) {
		
		String s = "software_development_in_test_developmentt";
		System.out.println("The length longest sub String is : " + lengthOfLongestSubString(s));
	}

}
