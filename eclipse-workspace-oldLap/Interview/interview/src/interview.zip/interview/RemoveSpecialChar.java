package interview;

public class RemoveSpecialChar {
	public static void removeSpecialChar(String str)
	{
		String reGenStr = str.replaceAll("[^A-Za-z0-9]","");
		System.out.println(reGenStr);
	}
	public static void main(String[] args) {
		String str = "SHReedhar@123";
		removeSpecialChar(str);
		
	}

}
